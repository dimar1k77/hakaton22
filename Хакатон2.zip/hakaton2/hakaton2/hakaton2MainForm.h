#pragma once
//using namespace Microsoft::Office::Interop::Word;
//
//#define Word   Microsoft::Office::Interop::Word;
namespace hakaton2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;


	/// <summary>
	/// ������ ��� hakaton2MainForm
	/// </summary>
	public ref class hakaton2MainForm : public System::Windows::Forms::Form
	{
	public:
		hakaton2MainForm(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~hakaton2MainForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::MenuStrip^ MainmenuStrip;
	private: System::Windows::Forms::ToolStripMenuItem^ FileToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ SaveToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ TocreateToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ OpenToolStripMenuItem;
	private: System::Windows::Forms::RichTextBox^ richTextBoxToCreate;
	private: System::Windows::Forms::OpenFileDialog^ openFileDialogRTF;
	private: System::Windows::Forms::SaveFileDialog^ saveFileDialogRTF;
	private: System::Windows::Forms::ToolStripMenuItem^ ��������ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ FileCreateToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^ ExitToolStripMenuItem;



	protected:


	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->MainmenuStrip = (gcnew System::Windows::Forms::MenuStrip());
			this->FileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->TocreateToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->OpenToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->SaveToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->��������ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->FileCreateToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->richTextBoxToCreate = (gcnew System::Windows::Forms::RichTextBox());
			this->openFileDialogRTF = (gcnew System::Windows::Forms::OpenFileDialog());
			this->saveFileDialogRTF = (gcnew System::Windows::Forms::SaveFileDialog());
			this->ExitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->MainmenuStrip->SuspendLayout();
			this->SuspendLayout();
			// 
			// MainmenuStrip
			// 
			this->MainmenuStrip->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {
				this->FileToolStripMenuItem,
					this->��������ToolStripMenuItem
			});
			this->MainmenuStrip->Location = System::Drawing::Point(0, 0);
			this->MainmenuStrip->Name = L"MainmenuStrip";
			this->MainmenuStrip->Size = System::Drawing::Size(818, 24);
			this->MainmenuStrip->TabIndex = 0;
			this->MainmenuStrip->Text = L"menuStrip1";
			// 
			// FileToolStripMenuItem
			// 
			this->FileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {
				this->TocreateToolStripMenuItem,
					this->OpenToolStripMenuItem, this->SaveToolStripMenuItem, this->ExitToolStripMenuItem
			});
			this->FileToolStripMenuItem->Name = L"FileToolStripMenuItem";
			this->FileToolStripMenuItem->Size = System::Drawing::Size(48, 20);
			this->FileToolStripMenuItem->Text = L"����";
			// 
			// TocreateToolStripMenuItem
			// 
			this->TocreateToolStripMenuItem->Name = L"TocreateToolStripMenuItem";
			this->TocreateToolStripMenuItem->Size = System::Drawing::Size(180, 22);
			this->TocreateToolStripMenuItem->Text = L"������� ������";
			this->TocreateToolStripMenuItem->Click += gcnew System::EventHandler(this, &hakaton2MainForm::TocreateToolStripMenuItem_Click);
			// 
			// OpenToolStripMenuItem
			// 
			this->OpenToolStripMenuItem->Name = L"OpenToolStripMenuItem";
			this->OpenToolStripMenuItem->Size = System::Drawing::Size(180, 22);
			this->OpenToolStripMenuItem->Text = L"������� ������";
			this->OpenToolStripMenuItem->Click += gcnew System::EventHandler(this, &hakaton2MainForm::OpenToolStripMenuItem_Click);
			// 
			// SaveToolStripMenuItem
			// 
			this->SaveToolStripMenuItem->Name = L"SaveToolStripMenuItem";
			this->SaveToolStripMenuItem->Size = System::Drawing::Size(180, 22);
			this->SaveToolStripMenuItem->Text = L"��������� ������";
			this->SaveToolStripMenuItem->Click += gcnew System::EventHandler(this, &hakaton2MainForm::SaveToolStripMenuItem_Click);
			// 
			// ��������ToolStripMenuItem
			// 
			this->��������ToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->FileCreateToolStripMenuItem });
			this->��������ToolStripMenuItem->Name = L"��������ToolStripMenuItem";
			this->��������ToolStripMenuItem->Size = System::Drawing::Size(73, 20);
			this->��������ToolStripMenuItem->Text = L"��������";
			// 
			// FileCreateToolStripMenuItem
			// 
			this->FileCreateToolStripMenuItem->Name = L"FileCreateToolStripMenuItem";
			this->FileCreateToolStripMenuItem->Size = System::Drawing::Size(117, 22);
			this->FileCreateToolStripMenuItem->Text = L"�������";
			this->FileCreateToolStripMenuItem->Click += gcnew System::EventHandler(this, &hakaton2MainForm::FileCreateToolStripMenuItem_Click);
			// 
			// richTextBoxToCreate
			// 
			this->richTextBoxToCreate->Location = System::Drawing::Point(34, 61);
			this->richTextBoxToCreate->Name = L"richTextBoxToCreate";
			this->richTextBoxToCreate->Size = System::Drawing::Size(738, 323);
			this->richTextBoxToCreate->TabIndex = 1;
			this->richTextBoxToCreate->Text = L"";
			// 
			// openFileDialogRTF
			// 
			this->openFileDialogRTF->FileName = L"openFileDialog1";
			// 
			// ExitToolStripMenuItem
			// 
			this->ExitToolStripMenuItem->Name = L"ExitToolStripMenuItem";
			this->ExitToolStripMenuItem->Size = System::Drawing::Size(180, 22);
			this->ExitToolStripMenuItem->Text = L"�����";
			this->ExitToolStripMenuItem->Click += gcnew System::EventHandler(this, &hakaton2MainForm::ExitToolStripMenuItem_Click);
			// 
			// hakaton2MainForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(818, 423);
			this->Controls->Add(this->richTextBoxToCreate);
			this->Controls->Add(this->MainmenuStrip);
			this->MainMenuStrip = this->MainmenuStrip;
			this->Name = L"hakaton2MainForm";
			this->Text = L"hakaton2MainForm";
			this->MainmenuStrip->ResumeLayout(false);
			this->MainmenuStrip->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void SaveToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		saveFileDialogRTF->FileName = "";
		saveFileDialogRTF->Filter = "RTF files (*.rtf)|*.rtf";
		saveFileDialogRTF->DefaultExt = "rtf";
		if (saveFileDialogRTF->ShowDialog() == System::Windows::Forms::DialogResult::OK &&
			saveFileDialogRTF->FileName->Length > 0) {
			try {
				richTextBoxToCreate->SaveFile(saveFileDialogRTF->FileName, RichTextBoxStreamType::RichText);
			}
			catch (...) {
				MessageBox::Show("�� ���� ��������� ���� " + System::IO::Path::GetFileName(saveFileDialogRTF->FileName) +
					"\n��������� ��� ��� � ����� �������", "������", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
				return;
			}
		}
	}
	private: System::Void TocreateToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		richTextBoxToCreate->Clear();
	}
	private: System::Void OpenToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		openFileDialogRTF->FileName = "";
		openFileDialogRTF->Filter = "RTF files (*.rtf)|*.rtf|All files (*.*)|*.*";
		if (openFileDialogRTF->ShowDialog() == System::Windows::Forms::DialogResult::OK &&
			openFileDialogRTF->FileName->Length > 0) {
			try {
				richTextBoxToCreate->LoadFile(openFileDialogRTF->FileName);
			}
			catch (...) {
				MessageBox::Show("�� ���� ������� ���� " + System::IO::Path::GetFileName(openFileDialogRTF->FileName) +
					"\n��������� ��� ���, ����� ������� � ������ (����� RTF)", "������", MessageBoxButtons::OK, MessageBoxIcon::Asterisk);
				return;
			}
		}
	}
	
private: System::Void FileCreateToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
	auto Word1 = gcnew Microsoft::Office::Interop::Word::ApplicationClass();
	Word1->Visible = true;
	System::Object^ missing = System::Reflection::Missing::Value;
	auto Doc1 = Word1->Documents->Add(missing, missing, missing, missing);
	Doc1->Words->First->InsertBefore(richTextBoxToCreate->Text);

	//Object^ FileName = "C:\\Linkey\\report.docx";
	//Word1->ActiveDocument->SaveAs(FileName);
	//Object^ tt = Microsoft::Office::Interop::Word::WdSaveOptions::wdDoNotSaveChanges; //�� ��������� ��������
	//Word1->Documents->Close(tt, missing, missing); // ������� �������� Word ��� ����������
	//Word1->Quit(tt, missing, missing);
	//Word1 = nullptr;
}
private: System::Void ExitToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Close();
}
};
}
